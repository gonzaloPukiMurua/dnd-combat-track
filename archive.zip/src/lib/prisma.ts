import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["error"], // you can add "query" for debugging if needed
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}